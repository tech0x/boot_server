#ifndef _IPXE_LOGIN_UI_H
#define _IPXE_LOGIN_UI_H

/** @file
 *
 * Login UI
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

extern int login_ui ( void );

#endif /* _IPXE_LOGIN_UI_H */
