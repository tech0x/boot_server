#ifndef _IPXE_FTP_H
#define _IPXE_FTP_H

/** @file
 *
 * File transfer protocol
 *
 */

FILE_LICENCE ( GPL2_OR_LATER_OR_UBDL );

/** FTP default port */
#define FTP_PORT 21

#endif /* _IPXE_FTP_H */
